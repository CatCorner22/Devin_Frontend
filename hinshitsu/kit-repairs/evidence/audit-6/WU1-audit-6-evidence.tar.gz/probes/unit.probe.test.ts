import { appendFileSync } from 'node:fs';
import { it } from 'vitest';
const KIT = process.env.KIT!;
const out = (s: string) => appendFileSync(process.env.PROBE_OUT!, s + '\n');
it('probe', async () => {
  const kit = await import(`${KIT}/packages/kit/src/index.ts`);
  const { placeholderIn, designId, repairPlan, KIT_RULES } = kit;
  const groups: Record<string, string[]> = {
    'B1 trigger': ['Tel+44 1632 555-0142', 'Whatsapp+44 1632 555-0142', 'x+44 1632 555-0142', '9+44 1632 555-0142', 'Version 1.0+44 1632 555-0142', 'Tel:+44 1632 555-0142'],
    'B1 second (mine)': ['Fax+353 1234 555-0142', 'Mobil+49 1512 555-0142', 'Büro+43 6641 555-0142', 'T+61 491 555-0142', '2+7 4951 555-0142', 'tel+81 3123 555-0142', 'Tel+971 5012 555-0142', '<b>Tel</b>+44 1632 555-0142'],
    'B2 trigger': ['Total 5 +3 2024 555-0100', 'Gain +12 2024 555-0100', 'Call +11 212 555-0142', 'Call +12 125 555-0142', 'Call +19 123 555-0142', 'Call +01 212 555-0142'],
    'B2 second (mine)': ['Net +5 2024 555-0100', 'Up +28 2024 555-0100', 'Rate +83 2024 555-0100', 'Call +0 2024 555-0100', 'Call +00 2024 555-0100', 'Call +999 2024 555-0100x', 'Add +2 1234 555-0100', 'Temp +38 2024 555-0100', 'Call +1242 555-0100', 'Call +100 2024 555-0100', 'Score +4 2024 555-0100', 'Call +89 2024 555-0100', 'Call +69 2024 555-0100'],
    'earlier results kept': ['Call +1 212 555-0142', 'Call +1-212-555-0199', 'Total 5+3 2024 555-0100', 'a+1 800 555-0100', 'Call +44 1632 555-0142', 'Call +44 113 555-0142', 'Tel. +353 1234 555-0142', 'Ring +44.1632.555-0142', 'Ring +44-113-555-0142', '(+44 1632 555-0142)', 'Call +7 4212 555-0142', 'Call +61 491 555-0142', 'CALL +44 1632 555-0142', 'Call (0113) 555-0142', 'Call 0113 555-0142', 'Call (212) 555-0142', 'Leeds office 0113 555-0142. New York office (212) 555-0199.', 'Year 2024 555-0100 is our line', 'Call ++1 212 555-0142', 'Call +1 212 555-0142 or +44 1632 555-0142', '2+2 113 555-0142'],
    'hunt: sums and words now excused': ['Total 5+44 2024 555-0100', 'Total 5 +44 2024 555-0100', 'Gain +7 2024 555-0100', 'a+7 800 555-0100', 'x+20 2024 555-0100', 'Step 3+30 2024 555-0100', 'Call +44 1632 555-0142 and 555-0100', 'Call +44 1632 555-0142 555-0100'],
    'hunt: codes the union does not give out': ['Call +210 2024 555-0100', 'Call +259 2024 555-0100', 'Call +295 2024 555-0100', 'Call +384 2024 555-0100', 'Call +422 2024 555-0100', 'Call +854 2024 555-0100', 'Call +801 2024 555-0100', 'Call +884 2024 555-0100', 'Call +990 2024 555-0100', 'Call +969 2024 555-0100', 'Call +28 2024 555-0100', 'Call +83 2024 555-0100', 'Call +89 2024 555-0100'],
    'hunt: longest-match and separators': ['Call +77 123 555-0142', 'Call +441 632 555-0142', 'Call +44  1632 555-0142', 'Call +44\u00a01632\u00a0555-0142', 'Call +44 16321 555-0142', 'Call +44 16 555-0142', 'Call +7 495 555-0142', 'Call +7495 555-0142', 'call +1 0113 555-0142', 'Call +\u0664\u0664 1632 555-0142', 'Call ＋44 1632 555-0142', 'Call +44 1632 555-01420'],
  };
  // every assigned ITU code
  const itu = ['7','20','27','30','31','32','33','34','36','39','40','41','43','44','45','46','47','48','49','51','52','53','54','55','56','57','58','60','61','62','63','64','65','66','81','82','84','86','90','91','92','93','94','95','98',
    '211','212','213','216','218','220','221','222','223','224','225','226','227','228','229','230','231','232','233','234','235','236','237','238','239','240','241','242','243','244','245','246','247','248','249','250','251','252','253','254','255','256','257','258','260','261','262','263','264','265','266','267','268','269','290','291','297','298','299',
    '350','351','352','353','354','355','356','357','358','359','370','371','372','373','374','375','376','377','378','379','380','381','382','383','385','386','387','389','420','421','423',
    '500','501','502','503','504','505','506','507','508','509','590','591','592','593','594','595','596','597','598','599','670','672','673','674','675','676','677','678','679','680','681','682','683','685','686','687','688','689','690','691','692',
    '800','808','850','852','853','855','856','870','878','880','881','882','883','886','888','960','961','962','963','964','965','966','967','968','970','971','972','973','974','975','976','977','979','991','992','993','994','995','996','998'];
  const blamed = itu.filter((c) => placeholderIn(`Call +${c} 1632 555-0142`) !== null);
  out(`## ${KIT}`);
  out(`assigned codes (${itu.length}) whose number is blamed: ${JSON.stringify(blamed)}`);
  const all: string[] = []; for (let i = 0; i < 1000; i++) { const c = String(i); if (placeholderIn(`Call +${c} 1632 555-0142`) === null) all.push(c); for (const z of ['0', '00']) if (c.length < 3 && (z + c).length <= 3 && placeholderIn(`Call +${z}${c} 1632 555-0142`) === null) all.push(z + c); }
  out(`digit strings of 1 to 3 digits excused after "+": ${all.length}; not in my list of assigned codes: ${JSON.stringify(all.filter((c) => !itu.includes(c)))}`);
  for (const [g, list] of Object.entries(groups)) { out(`# ${g}`); for (const t of list) out(`placeholderIn(${JSON.stringify(t)}) -> ${JSON.stringify(placeholderIn(t))}`); }
  out('# B3');
  const ids: [string, unknown][] = [['9007199254740993n', 9007199254740993n], ['9007199254740993', 9007199254740993], ["'9007199254740993'", '9007199254740993'], ['12345678901234567890n', 12345678901234567890n], ['12345678901234567890', 12345678901234567890], ['12345678901234567000n', 12345678901234567000n], ['12345678901234567000', 12345678901234567000], ['9007199254740992n', 9007199254740992n], ['9007199254740992', 9007199254740992],
    ['2n**64n', 2n ** 64n], ['2**64', 2 ** 64], ['100000000000000000000n', 10n ** 20n], ['1e20', 1e20], ['36028797018963970n', 36028797018963970n], ['36028797018963970', 36028797018963970], ['-9007199254740993n', -9007199254740993n], ['-9007199254740993', -9007199254740993], ['0n', 0n], ['-0', -0], ['1.5', 1.5], ['1e21', 1e21], ['10n**21n', 10n ** 21n]];
  for (const [label, v] of ids) out(`designId({ t: ${label} }) -> ${designId({ t: v } as never)}   String(value)=${String(v)}${typeof v === 'number' ? `   exact value=${Number.isInteger(v) ? BigInt(v).toString() : 'not whole'}` : ''}`);
  out('# judge.ts');
  const f = (ruleId: unknown) => [{ ruleId, status: 'fails', where: 'p' }];
  const show = (label: string, plan: any) => out(`${label} -> ${JSON.stringify(plan.items?.map((i: any) => ({ ruleId: i.ruleId, fix: i.fix })))}`);
  const known = KIT_RULES[0];
  show(`known rule ${known.id}`, repairPlan([f(known.id)] as never, KIT_RULES));
  show('unknown rule "nope"', repairPlan([f('nope')] as never, KIT_RULES));
  for (const [label, rule] of [['plain missing', { ...known, plain: undefined }], ['plain null', { ...known, plain: null }], ['plain empty', { ...known, plain: '' }], ['plain 0', { ...known, plain: 0 }]] as const) {
    try { show(`rule given with ${label}`, repairPlan([f(known.id)] as never, [rule] as never)); } catch (e) { out(`rule given with ${label} -> throws ${String(e)}`); }
  }
  for (const id of ['__proto__', 'constructor', 'toString', '']) { try { show(`ruleId ${JSON.stringify(id)}`, repairPlan([f(id)] as never, KIT_RULES)); } catch (e) { out(`ruleId ${id} -> throws ${String(e)}`); } }
});
