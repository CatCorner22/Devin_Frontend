import { defineConfig } from 'vitest/config';
export default defineConfig({ test: { include: [process.env.PROBE_FILE ?? ''], environment: 'node', testTimeout: 600_000, hookTimeout: 90_000, fileParallelism: false } });
