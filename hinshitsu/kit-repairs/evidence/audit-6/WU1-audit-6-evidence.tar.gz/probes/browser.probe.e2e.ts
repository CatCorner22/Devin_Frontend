import { appendFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
import { chromium, type Browser, type Page } from 'playwright';
import { afterAll, beforeAll, it } from 'vitest';
const KIT = process.env.KIT!;
const out = (s: string) => appendFileSync(process.env.PROBE_OUT!, s + '\n');
const TOKENS = { '--ink': '#1a1a1a', '--paper': '#ffffff', '--accent': '#0b5fff', '--line': '#d0d5dd', '--radius': '8px', '--radius-in': '4px', '--font-body': 'serif' };
let browser: Browser; let checks: Record<string, unknown>; let counter: Page;
beforeAll(async () => {
  browser = await chromium.launch({ executablePath: process.env.PW_CHROMIUM });
  checks = await import(`${KIT}/packages/kit/src/page-checks/index.ts`);
  counter = await (await browser.newContext()).newPage();
  out(`## ${KIT}  Chromium ${browser.version()}`);
});
afterAll(async () => { await browser.close(); });
const pageOf = async (body: string, style: string, base = 'body{color:#1a1a1a;background:#ffffff;font-family:serif;margin:24px}'): Promise<Page> => {
  const page = await (await browser.newContext({ viewport: { width: 1280, height: 800 } })).newPage();
  await page.setContent(`<!doctype html><html lang="en"><head><title>t</title><style>${base} ${style}</style></head><body>${body}</body></html>`);
  return page;
};
const run = async (page: Page, fn: string): Promise<any[]> => page.evaluate(`(${String(checks[fn])})(document${fn === 'tokenFit' ? `, ${JSON.stringify(TOKENS)}` : ''})`) as Promise<any[]>;
// Counts the pixels of the screenshot that are near rgb(255, 0, 170).
const pink = async (page: Page): Promise<number> => {
  const png = (await page.screenshot()).toString('base64');
  return counter.evaluate(async (b64) => { const img = new Image(); img.src = `data:image/png;base64,${b64}`; await img.decode(); const c = document.createElement('canvas'); c.width = img.width; c.height = img.height; const g = c.getContext('2d')!; g.drawImage(img, 0, 0); const d = g.getImageData(0, 0, c.width, c.height).data; let n = 0; for (let i = 0; i < d.length; i += 4) if (d[i]! > 200 && d[i + 1]! < 90 && d[i + 2]! > 110 && d[i + 2]! < 220) n += 1; return n; }, png);
};
const gif = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw==';
const long = 'Bread and rolls, baked each morning in our own oven, from flour milled in the next valley. '.repeat(6);
const fit = async (label: string, body: string, style: string): Promise<void> => {
  const page = await pageOf(body, style);
  const f = (await run(page, 'tokenFit')).filter((x) => x.ruleId === 'fit-colors');
  const fails = f.filter((x) => x.status === 'fails').map((x) => `${x.measured} @${x.where}`);
  out(`${label}\n    body: ${body.length > 260 ? body.slice(0, 260) + '…' : body}\n    style: ${style}\n    fit-colors: ${fails.length ? 'FAILS ' + JSON.stringify(fails) : JSON.stringify(f.map((x) => x.status))}   pink pixels drawn: ${await pink(page)}`);
  await page.context().close();
};
it('tokenFit: the six places', async () => {
  out('# ITEM 2: six places, one faulty and one sound page each (off-design color #ff00aa)');
  await fit('1 text stroke, faulty', '<h2 class="t">Fresh loaves</h2>', '.t{font-size:48px;-webkit-text-stroke:2px #ff00aa}');
  await fit('1 text stroke, sound', '<h2 class="t">Fresh loaves</h2>', '.t{font-size:48px;-webkit-text-stroke:2px #0b5fff}');
  await fit('2 column rule, faulty', `<div class="c">${long}</div>`, '.c{columns:3;column-rule:3px dashed #ff00aa}');
  await fit('2 column rule, sound', `<div class="c">${long}</div>`, '.c{columns:3;column-rule:3px dashed #d0d5dd}');
  await fit('3 border fade, faulty', '<div class="b">Opening hours</div>', '.b{padding:12px;border:6px solid #d0d5dd;border-image:conic-gradient(#ff00aa, #0b5fff) 1}');
  await fit('3 border fade, sound', '<div class="b">Opening hours</div>', '.b{padding:12px;border:6px solid #d0d5dd;border-image:conic-gradient(#d0d5dd, #0b5fff) 1}');
  await fit('4 drop shadow, faulty', `<img class="s" alt="Loaf" width="80" height="60" src="${gif}">`, '.s{filter:blur(0px) drop-shadow(6px 6px 0 #ff00aa)}');
  await fit('4 drop shadow, sound', `<img class="s" alt="Loaf" width="80" height="60" src="${gif}">`, '.s{filter:blur(0px) drop-shadow(6px 6px 0 #1a1a1a)}');
  await fit('5 accent, faulty (a checked radio button and a progress bar)', '<label><input type="radio" name="r" checked class="r"> Rye</label> <label>Baked <progress class="r" value="0.4"></progress></label>', '.r{accent-color:#ff00aa}');
  await fit('5 accent, sound', '<label><input type="radio" name="r" checked class="r"> Rye</label> <label>Baked <progress class="r" value="0.4"></progress></label>', '.r{accent-color:#0b5fff}');
  await fit('6 list marker, faulty (a numbered list)', '<ol class="l"><li>Knead</li><li>Prove</li></ol>', '.l{font-size:32px} .l li::marker{color:#ff00aa}');
  await fit('6 list marker, sound', '<ol class="l"><li>Knead</li><li>Prove</li></ol>', '.l{font-size:32px} .l li::marker{color:#0b5fff}');
  out('# README: places said to be not read (each page carries #ff00aa in that place only; "holds" = not read)');
  await fit('R1 ::first-letter', '<p class="p">Bread</p>', '.p{font-size:40px} .p::first-letter{color:#ff00aa}');
  await fit('R2 ::selection', '<p class="p">Bread</p>', '.p::selection{background:#ff00aa}');
  await fit('R3 border-image that is a picture file', '<p class="p">Bread</p>', `.p{border:8px solid #d0d5dd;border-image:url("data:image/svg+xml,${encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="30" height="30"><rect width="30" height="30" fill="#ff00aa"/></svg>')}") 10}`);
  await fit('R4 stops of an SVG gradient', '<svg width="120" height="60"><defs><linearGradient id="g"><stop offset="0" stop-color="#ff00aa"/><stop offset="1" stop-color="#ff00aa"/></linearGradient></defs><rect width="120" height="60" fill="url(#g)"/></svg>', '');
  await fit('R5 a drawing brought in by SVG use', '<svg width="0" height="0"><defs><rect id="sq" width="60" height="60" fill="#ff00aa"/></defs></svg><svg width="120" height="60"><use href="#sq"/></svg>', '');
  await fit('R6 pseudo-element (color is read; shown for contrast)', '<p class="p">Bread</p>', '.p::before{content:"x";color:#ff00aa}');
  out('# Places the README list does not name (hunt): is the color read?');
  await fit('U1 ::placeholder', '<label>Name <input class="i" placeholder="Your name"></label>', '.i{color:#1a1a1a;background:#fff;border:1px solid #d0d5dd;font-family:serif;font-size:32px} .i::placeholder{color:#ff00aa;opacity:1}');
  await fit('U2 ::first-line', '<p class="p">Bread</p>', '.p{font-size:40px} .p::first-line{color:#ff00aa}');
  await fit('U3 text-emphasis', '<p class="p">Bread</p>', '.p{font-size:40px;text-emphasis:filled circle #ff00aa}');
  await fit('U4 scrollbar-color', `<div class="p">${long}${long}</div>`, '.p{height:80px;overflow-y:scroll;scrollbar-color:#ff00aa #ff00aa}');
  await fit('U5 drop-shadow on an inline <svg> element', '<svg class="s" width="80" height="60"><rect width="80" height="60" fill="#1a1a1a"/></svg>', '.s{filter:drop-shadow(6px 6px 0 #ff00aa)}');
  await fit('U6 column rule where the columns come from column-width', `<div class="c">${long}</div>`, '.c{column-width:200px;column-rule:3px solid #ff00aa}');
  await fit('U7 backdrop-filter drop-shadow', '<div class="p">Bread</div>', '.p{backdrop-filter:drop-shadow(6px 6px 0 #ff00aa)}');
  await fit('U8 <summary> marker', '<details><summary class="m">Hours</summary>9 to 5</details>', '.m{font-size:32px} .m::marker{color:#ff00aa}');
  await fit('U9 display: inline list-item', '<ul><li class="m">Rolls</li></ul>', '.m{display:inline list-item;font-size:32px} .m::marker{color:#ff00aa}');
  await fit('U10 fill of ::marker background / text-decoration on ::before', '<p class="p">Bread</p>', '.p::before{content:"x";color:#1a1a1a;text-decoration:underline #ff00aa;outline:3px solid #ff00aa}');
  await fit('U11 border fade written as repeating-linear-gradient with a named color', '<div class="b">Hours</div>', '.b{border:6px solid #d0d5dd;border-image:repeating-linear-gradient(45deg, deeppink 0 4px, #0b5fff 4px 8px) 1}');
  await fit('U12 drop-shadow with a named color', `<img class="s" alt="Loaf" width="80" height="60" src="${gif}">`, '.s{filter:drop-shadow(6px 6px 0 deeppink)}');
  await fit('U13 column rule whose color is currentColor of an off-design text color, no text of its own', `<div class="c"><p>${long}</p></div>`, '.c{columns:2;color:#ff00aa;column-rule:3px solid} .c p{color:#1a1a1a;margin:0}');
  out('# Sound pages (nothing off-design is drawn): is the page blamed?');
  await fit('S1 two columns asked for, text fills one line only', '<p class="c">Bread</p>', '.c{column-count:2;column-rule:3px solid #ff00aa}');
  await fit('S2 border fade set, border of no width', '<p class="b">Bread</p>', '.b{border-image:linear-gradient(#ff00aa, #ff00aa) 1}');
  await fit('S3 border fade set, border-style none', '<p class="b">Bread</p>', '.b{border:0 none;border-image:linear-gradient(#ff00aa, #ff00aa) 1 / 0}');
  await fit('S4 accent on a meter', '<label>Stock <meter class="m" value="0.6"></meter></label>', '.m{accent-color:#ff00aa}');
  await fit('S5 accent on a checkbox that is not checked', '<label><input type="checkbox" class="m"> Rye</label>', '.m{accent-color:#ff00aa}');
  await fit('S5b the same checkbox, checked', '<label><input type="checkbox" checked class="m"> Rye</label>', '.m{accent-color:#ff00aa}');
  await fit('S6 accent on a checked checkbox with appearance: none', '<label><input type="checkbox" checked class="m"> Rye</label>', '.m{appearance:none;width:16px;height:16px;border:1px solid #1a1a1a;accent-color:#ff00aa}');
  await fit('S7 marker with content: none', '<ul><li class="m">Rolls</li></ul>', '.m::marker{content:none;color:#ff00aa}');
  await fit('S8 marker with empty content', '<ul><li class="m">Rolls</li></ul>', '.m::marker{content:"";color:#ff00aa}');
  await fit('S9 list-style-type: "" (empty text)', '<ul><li class="m">Rolls</li></ul>', '.m{list-style-type:""} .m::marker{color:#ff00aa}');
  await fit('S10 the bullet is a picture', '<ul><li class="m"><span>Rolls</span></li></ul>', `.m{list-style-image:url("data:image/svg+xml,${encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="10" height="10"><rect width="10" height="10" fill="#0b5fff"/></svg>')}")} .m::marker{color:#ff00aa}`);
  await fit('S11 drop shadow that is clear', '<p class="b">Bread</p>', '.b{filter:drop-shadow(0 0 0 transparent)}');
  await fit('S12 filter drop-shadow on a part with opacity 0', '<p class="b">Bread</p>', '.b{opacity:0;filter:drop-shadow(6px 6px 0 #ff00aa)}');
  await fit('S13 text stroke on a part whose text is visibility: hidden', '<p class="b">Bread</p>', '.b{visibility:hidden;-webkit-text-stroke:2px #ff00aa}');
  await fit('S14 plain page: lists, a checkbox, a slider, columns in design colors by default', `<ul><li>Rolls</li></ul><ol><li><span>Buns</span></li></ol><details><summary>Hours</summary>9</details><label><input type="checkbox" checked> Rye</label><input type="range" aria-label="Loaves"><progress value="0.5" aria-label="Baked"></progress><div style="columns:2">${long}</div>`, '');
  await fit('S15 accent that is a design color on the root, inherited', '<label><input type="checkbox" checked> Rye</label>', 'html{accent-color:#0b5fff}');
  out('# Fixtures of the kit, tokenFit (compare between commits)');
  for (const name of ['good.html', 'flawed.html']) {
    const page = await (await browser.newContext({ viewport: { width: 1280, height: 800 } })).newPage();
    await page.goto(pathToFileURL(`${KIT}/packages/kit/fixtures/${name}`).href); await page.waitForTimeout(400);
    out(`${name}: ${JSON.stringify((await run(page, 'tokenFit')).map((x) => `${x.ruleId}:${x.status}:${x.measured ?? ''}`))}`);
    await page.context().close();
  }
});
const stat = async (label: string, fn: string, body: string, style = ''): Promise<void> => {
  const page = await pageOf(body, style, 'body{font:16px/1.5 Arial,sans-serif;margin:24px}');
  const f = await run(page, fn);
  let extra = '';
  if (fn === 'controlsHaveNames') {
    const cdp = await page.context().newCDPSession(page);
    const tree = await cdp.send('Accessibility.getFullAXTree') as any;
    extra = '   name Chromium computes: ' + JSON.stringify(tree.nodes.filter((n: any) => /^(button|link)$/.test(n.role?.value)).map((n: any) => n.name?.value ?? ''));
  } else {
    const seen: number[] = [];
    for (let i = 0; i < 12; i++) { seen.push(await page.evaluate(() => { const el = document.querySelector('input'); return el ? Number(getComputedStyle(el, '::placeholder').opacity) : NaN; })); await page.waitForTimeout(90); }
    extra = `   placeholder opacity in 12 readings: ${Math.min(...seen).toFixed(2)} to ${Math.max(...seen).toFixed(2)}`;
  }
  out(`${label}\n    body: ${body}\n    style: ${style}\n    ${fn}: ${JSON.stringify(f.map((x) => `${x.status}${x.where ? ' @' + x.where : ''}${x.measured ? ' [' + x.measured + ']' : ''}`))}${extra}`);
  await page.context().close();
};
it('item 5', async () => {
  out('# ITEM 5a: controlsHaveNames, the hidden target of aria-labelledby');
  await stat('faulty 1: the target is shown, its only text is hidden inside it', 'controlsHaveNames', '<button aria-labelledby="n"><svg width="16" height="16" aria-hidden="true"><path d="M2 2l12 12"/></svg></button><p id="n"><span style="display:none">Delete the order</span></p>');
  await stat('faulty 2: the target is hidden and holds only a style sheet', 'controlsHaveNames', '<button aria-labelledby="n"><svg width="16" height="16" aria-hidden="true"><path d="M2 2l12 12"/></svg></button><div id="n" hidden><style>.x{color:red}</style></div>');
  await stat('faulty 3: the target is shown, its text sits in a part marked aria-hidden', 'controlsHaveNames', '<a href="/cart" aria-labelledby="n"><svg width="16" height="16" aria-hidden="true"><path d="M2 2l12 12"/></svg></a><p id="n"><span aria-hidden="true">Cart</span></p>');
  await stat('sound 1: the target itself is hidden (the hidden attribute)', 'controlsHaveNames', '<button aria-labelledby="n"><svg width="16" height="16" aria-hidden="true"><path d="M2 2l12 12"/></svg></button><span id="n" hidden>Delete the order</span>');
  await stat('sound 2: the target is visibility: hidden inside a hidden wrapper', 'controlsHaveNames', '<a href="/cart" aria-labelledby="n"><svg width="16" height="16" aria-hidden="true"><path d="M2 2l12 12"/></svg></a><div aria-hidden="true"><span id="n" style="visibility:hidden">Open the cart</span></div>');
  await stat('sound 3: two targets, one shown and one hidden', 'controlsHaveNames', '<button aria-labelledby="a b"><svg width="16" height="16" aria-hidden="true"><path d="M2 2l12 12"/></svg></button><span id="a">Remove</span><span id="b" style="display:none">rye loaf</span>');
  out('# ITEM 5b: noEndlessMotion, the placeholder animation');
  const field = '<label for="q">Search</label><input id="q" placeholder="words">';
  await stat('faulty 1: one animation without end', 'noEndlessMotion', field, '@keyframes fade { 50% { opacity: 0.2 } } input::placeholder { animation: fade 1.2s ease-in-out infinite; }');
  await stat('faulty 2: an animation of no length beside one that moves without end', 'noEndlessMotion', field, '@keyframes still { to { opacity: 1 } } @keyframes fade { 50% { opacity: 0.2 } } input::placeholder { animation: still 0s infinite, fade 2s infinite; }');
  await stat('faulty 3: longhand properties, the second name moves', 'noEndlessMotion', field, '@keyframes one { to { opacity: 1 } } @keyframes two { 50% { opacity: 0.25 } } input::placeholder { animation-name: one, two; animation-duration: 1s, 1.5s; animation-iteration-count: 1, infinite; }');
  await stat('sound 1: an animation that runs 2 times and ends', 'noEndlessMotion', field, '@keyframes fade { 50% { opacity: 0.2 } } input::placeholder { animation: fade 0.3s 2; }');
  await stat('sound 2: an animation of no length, without end', 'noEndlessMotion', field, '@keyframes fade { 50% { opacity: 0.2 } } input::placeholder { animation: fade 0s infinite; }');
  await stat('sound 3: no animation; the field itself has a transition', 'noEndlessMotion', field, 'input { transition: border-color 0.2s; } input::placeholder { color: #666; }');
  await stat('sound 4: without end, but paused', 'noEndlessMotion', field, '@keyframes fade { 50% { opacity: 0.2 } } input::placeholder { animation: fade 1s infinite paused; }');
});
